
$(document).ready(function () {
    // $('body').css('display', 'none').fadeIn(1000);
    $('.head-text, .second-content').css('display', 'none').fadeIn(1500);
    $('.first-box, .icon, .second-box').css('display', 'none').slideDown(1500);
  
   
  
  });